
import { Component, ChangeDetectionStrategy, signal, computed, inject, effect, viewChild, ElementRef, AfterViewInit, untracked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Transaction } from './models/feature.model';
import * as d3 from 'd3';

const STORAGE_KEY = 'financial-transactions-v2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule],
})
export class AppComponent implements AfterViewInit {
  private fb = inject(FormBuilder);
  chartContainer = viewChild<ElementRef>('chartContainer');

  // State
  transactions = signal<Transaction[]>([]);
  currentDate = signal<Date>(new Date()); // For monthly filtering
  
  expenseCategories = ['Alimentação', 'Transporte', 'Moradia', 'Lazer', 'Saúde', 'Educação', 'Compras', 'Serviços'];
  
  categoryIcons: {[key: string]: string} = {
    'Alimentação': '🍔',
    'Transporte': '🚗',
    'Moradia': '🏡',
    'Lazer': '🎉',
    'Saúde': '❤️',
    'Educação': '🎓',
    'Compras': '🛍️',
    'Serviços': '⚡',
    'Entrada': '🤑'
  };

  transactionForm = this.fb.group({
    description: ['', Validators.required],
    amount: [null as number | null, [Validators.required, Validators.min(0.01)]],
    type: ['expense' as 'income' | 'expense', Validators.required],
    category: [''], // Optional initially
    date: [new Date().toISOString().substring(0, 10), Validators.required]
  });

  constructor() {
    // Load Data
    const storedTransactions = localStorage.getItem(STORAGE_KEY);
    if (storedTransactions) {
      try {
        this.transactions.set(JSON.parse(storedTransactions));
      } catch (e) {
        console.error("Error parsing data", e);
      }
    }

    // Save Data Effect
    effect(() => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.transactions()));
    });
    
    // Chart Update Effect
    effect(() => {
        const data = this.monthlyExpensesByCategory(); 
        const total = this.monthlyTotalExpenses();

        untracked(() => {
             if(this.chartContainer()) {
                // Small delay to ensure DOM is ready
                setTimeout(() => this.renderChart(data, total), 50);
            }
        });
    });

    // Form Logic: Clear category if switching to Income (since we don't need it)
    this.transactionForm.get('type')?.valueChanges.subscribe((type) => {
        if (type === 'income') {
            this.transactionForm.get('category')?.setValue('Entrada');
            this.transactionForm.get('category')?.disable();
        } else {
            this.transactionForm.get('category')?.setValue('');
            this.transactionForm.get('category')?.enable();
        }
    });
  }
  
  ngAfterViewInit() {
    this.renderChart(this.monthlyExpensesByCategory(), this.monthlyTotalExpenses());
  }

  // --- COMPUTED VALUES (The Brains) ---

  // Filter transactions by the selected month
  monthlyTransactions = computed(() => {
    const curr = this.currentDate();
    return this.transactions().filter(t => {
        const tDate = new Date(t.date);
        // Fix timezone offset issues for simple date matching
        return tDate.getMonth() === curr.getMonth() && tDate.getFullYear() === curr.getFullYear();
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  });

  monthlyTotalIncome = computed(() => 
    this.monthlyTransactions()
      .filter(t => t.type === 'income')
      .reduce((acc, t) => acc + t.amount, 0)
  );

  monthlyTotalExpenses = computed(() => 
    this.monthlyTransactions()
      .filter(t => t.type === 'expense')
      .reduce((acc, t) => acc + t.amount, 0)
  );

  monthlyBalance = computed(() => this.monthlyTotalIncome() - this.monthlyTotalExpenses());

  // Complex KPI: Savings Rate %
  savingsRate = computed(() => {
    const income = this.monthlyTotalIncome();
    const expense = this.monthlyTotalExpenses();
    if (income === 0) return 0;
    return Math.max(0, ((income - expense) / income) * 100);
  });

  // Complex KPI: Daily Average Spend
  dailyAverage = computed(() => {
     const expenses = this.monthlyTotalExpenses();
     const now = new Date();
     const selected = this.currentDate();
     
     let daysPassed;
     // If selected month is current month, use today's date. Else use total days in that month.
     if (selected.getMonth() === now.getMonth() && selected.getFullYear() === now.getFullYear()) {
         daysPassed = now.getDate();
     } else {
         daysPassed = new Date(selected.getFullYear(), selected.getMonth() + 1, 0).getDate();
     }
     
     return daysPassed > 0 ? expenses / daysPassed : 0;
  });

  monthlyExpensesByCategory = computed(() => {
    const expenses = this.monthlyTransactions().filter(t => t.type === 'expense');
    return expenses.reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
    }, {} as {[key: string]: number});
  });

  // Finds the category with highest spend
  topExpenseCategory = computed(() => {
      const categories = this.monthlyExpensesByCategory();
      let max = 0;
      let topCat = '';
      for(const [cat, val] of Object.entries(categories)) {
          const value = val as number;
          if (value > max) {
              max = value;
              topCat = cat;
          }
      }
      return topCat ? { name: topCat, amount: max } : null;
  });

  // --- ACTIONS ---

  changeMonth(delta: number) {
      const newDate = new Date(this.currentDate());
      newDate.setMonth(newDate.getMonth() + delta);
      this.currentDate.set(newDate);
  }

  get formattedCurrentMonth(): string {
      return this.currentDate().toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  }

  getCategoryIcon(category: string): string {
    return this.categoryIcons[category] || '🔹';
  }

  addTransaction(): void {
    if (this.transactionForm.invalid) {
        this.transactionForm.markAllAsTouched();
        return;
    }
    const formValue = this.transactionForm.getRawValue();
    
    // Auto-assign category for income
    const finalCategory = formValue.type === 'income' ? 'Entrada' : formValue.category;

    if (!finalCategory) return;

    const newTransaction: Transaction = {
      id: Date.now(),
      description: formValue.description!,
      amount: formValue.amount!,
      type: formValue.type!,
      category: finalCategory,
      date: formValue.date!
    };

    this.transactions.update((prev) => [newTransaction, ...prev]);
    
    // Reset form but keep the date and type somewhat consistent for UX
    this.transactionForm.reset({ 
        type: formValue.type, 
        amount: null, 
        description: '', 
        category: formValue.type === 'income' ? 'Entrada' : '',
        date: formValue.date
    });
    
    if(formValue.type === 'income') {
        this.transactionForm.get('category')?.disable();
    }
  }

  removeTransaction(id: number): void {
    if(confirm('Tem certeza que deseja apagar este registro?')) {
        this.transactions.update((prev) => prev.filter((t) => t.id !== id));
    }
  }

  // --- CHART ENGINE ---

  private renderChart(data: { [key: string]: number }, totalValue: number): void {
    const container = this.chartContainer()?.nativeElement;
    if (!container) return;

    // 1. CLEANUP
    d3.select(container).selectAll('*').remove();

    // 2. SETUP DIMENSIONS
    const width = 300;
    const height = 300;
    const margin = 20;
    const radius = Math.min(width, height) / 2 - margin;

    const svg = d3.select(container)
      .append("svg")
      .attr("viewBox", `0 0 ${width} ${height}`)
      .classed("w-full h-full drop-shadow-xl", true)
      .append("g")
      .attr("transform", `translate(${width / 2},${height / 2})`);

    // 3. EMPTY STATE
    if (Object.keys(data).length === 0) {
        const emptyArc = d3.arc()
            .innerRadius(radius * 0.65)
            .outerRadius(radius)
            .cornerRadius(20)
            .startAngle(0)
            .endAngle(2 * Math.PI);
        
        svg.append("path")
            .attr("d", emptyArc as any)
            .attr("fill", "#f8fafc") 
            .attr("stroke", "#e2e8f0") 
            .attr("stroke-dasharray", "5,5"); // Dashed line for empty state

        svg.append("text")
           .attr("text-anchor", "middle")
           .attr("dy", "0.3em")
           .classed("fill-slate-400 font-medium text-sm", true)
           .text("Sem dados");
        return;
    }

    // 4. COLORS (Premium Palette)
    const colorMap = d3.scaleOrdinal()
        .domain(this.expenseCategories)
        .range([
            '#8b5cf6', // Violet
            '#ec4899', // Pink
            '#f43f5e', // Rose
            '#f97316', // Orange
            '#eab308', // Yellow
            '#10b981', // Emerald
            '#06b6d4', // Cyan
            '#3b82f6', // Blue
            '#64748b'  // Slate
        ]);

    // 5. PIE GENERATOR
    const pie = d3.pie<any>()
        .value(d => d[1])
        .sort((a, b) => b[1] - a[1]) // Sort biggest first
        .padAngle(0.08); // More spacing between slices

    const data_ready = pie(Object.entries(data));

    // 6. ARCS
    const arc = d3.arc()
        .innerRadius(radius * 0.60) // Thicker donut
        .outerRadius(radius)
        .cornerRadius(15);

    const arcHover = d3.arc()
        .innerRadius(radius * 0.60)
        .outerRadius(radius + 10) // Pop out effect
        .cornerRadius(15);

    // 7. DRAW SLICES
    svg.selectAll('path')
      .data(data_ready)
      .join('path')
      .attr('d', arc as any)
      .attr('fill', d => colorMap(d.data[0]) as string)
      .style("cursor", "pointer")
      .style("transition", "opacity 0.3s")
      .on("mouseover", function(event, d) {
          d3.select(this).transition().duration(300).attr("d", arcHover as any);
          // Highlight corresponding legend item (optional advanced interaction)
      })
      .on("mouseout", function(event, d) {
          d3.select(this).transition().duration(300).attr("d", arc as any);
      })
      .transition()
      .duration(1200)
      .attrTween('d', function(d) {
          const i = d3.interpolate(d.startAngle + 0.1, d.endAngle);
          return function(t) {
              d.endAngle = i(t);
              return arc(d as any) || '';
          }
      });

    // 8. CENTER TEXT (Balance/Total)
    const centerGroup = svg.append("g");
    
    centerGroup.append("text")
       .attr("text-anchor", "middle")
       .attr("dy", "-0.5em")
       .style("font-size", "12px")
       .style("fill", "#64748b")
       .style("font-weight", "500")
       .text("Gastos do Mês");
       
    centerGroup.append("text")
       .attr("text-anchor", "middle")
       .attr("dy", "0.8em")
       .style("font-size", "22px")
       .style("fill", "#1e293b")
       .style("font-weight", "800")
       .text(`${(totalValue/1000).toFixed(1)}k`); // Abbreviated for style
  }
}
