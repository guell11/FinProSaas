
import { Component, ChangeDetectionStrategy, input } from '@angular/core';
// Fix: The 'Feature' type does not exist in feature.model.ts. Replaced with the 'Transaction' type.
import { Transaction } from '../../models/feature.model';

@Component({
  selector: 'app-feature-card',
  templateUrl: './feature-card.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FeatureCardComponent {
  feature = input.required<Transaction>();
}
